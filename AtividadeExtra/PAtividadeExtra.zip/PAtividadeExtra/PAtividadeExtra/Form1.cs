﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividadeExtra
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] valores = new double[7, 5];
            double[] TotalporDia = new double[7];
            double TotalGeral = 0;
            string[] Dias = { "domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sabado" };

            lstBxSaida.Items.Clear();
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if(!double.TryParse(Interaction.InputBox($"Digite o valor {j+1} de {Dias[i]}", "Entrada de Dados"), out valores[i, j]) && valores[i, j] <= 0){
                        MessageBox.Show("Valor deve ser um número maior que 0");
                        j--;
                    }
                    else
                    {
                        TotalporDia[i] += valores[i, j];
                    }
                }
            }
          
            for(int i = 0;i < 7; i++)
            {
                TotalGeral += TotalporDia[i];
                lstBxSaida.Items.Add($"{Dias[i]} - {TotalporDia[i]}\n");
            }
            lstBxSaida.Items.Add($"Total geral - {TotalGeral}");

        }
    }
}
