﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PConsumo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] setores = { "producao", "escritorio", "refeitorio", "limpeza", "logistica" };
            double[,] litros = new double[4, 5];
            double[] total = new double[5];
            double totalGeral = 0;
            string aux;

            lstbxSaida.Items.Clear();

            for (int i = 0; i < litros.GetLength(0); i++)
            {
                for(int j = 0; j < litros.GetLength(1); j++)
                {
                    aux = Interaction.InputBox($"Digite a quantidade de litros da semana {i + 1} referente ao setor {setores[j]}", "Entrada de dados");
                    if(!double.TryParse(aux, out litros[i, j])){
                        MessageBox.Show("Digite um valor aceito");
                        j--;
                    }
                    total[j] += litros[i,j];
                    totalGeral += litros[i,j];
                }
            }

            for(int i = 0; i < litros.GetLength(1); i++)
            {
                lstbxSaida.Items.Add($"{setores[i]}: {total[i]}L -> R${total[i] * 0.01:F2}");
            }
            lstbxSaida.Items.Add($"total geral: {totalGeral}L -> R${totalGeral * 0.01:F2}");
        }
    }
}
