﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade2
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if(this.ActiveControl == btnSair)
            {
                return;
            }
            if (!double.TryParse(mskbxPeso.Text, out peso) || peso <= 0)
            {
                MessageBox.Show("Peso invalido.");
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if(!double.TryParse(mskbxAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Altura invalida.");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = Math.Round((peso / (altura * altura)), 1);
            if (imc < 18.5)
            {
                txtIMC.Text = "Magreza " + imc;
            } 
            else if(imc <= 24.9)
            {
                txtIMC.Text = "Normal "+imc;
            } 
            else if(imc <= 29.9)
            {
                txtIMC.Text = "Sobrepeso "+imc;
            } 
            else if(imc <= 39.9)
            {
                txtIMC.Text = "Obesidade "+imc;
            }
            else
            {
                txtIMC.Text = "Obesidade Grave "+imc;
            }
        }
    }
}
